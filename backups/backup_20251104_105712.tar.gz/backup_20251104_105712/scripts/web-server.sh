#!/bin/bash
./simple-http.sh 8000
