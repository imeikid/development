#!/bin/bash
./simple-http.sh 8080
