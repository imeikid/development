#!/bin/bash
mkdir -p development/{css,js,images}
cat > development/index.html << "END"
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.1.00">
   ">
    <title>Строительство под ключ <title>Строительство под ключ в Боль в Большой Ялте</title>
</head>
<bodyшой Ялте</title>
</head>
<body>
>
    <h1>    <h1>Строительство под ключ в БольСтроительство под ключ в Большой Ялте</шой Ялте</h1>
</body>
</html>
h1>
</body>
</html>
END
echo "ПроEND
echo "Проектект создан в папке development/"
